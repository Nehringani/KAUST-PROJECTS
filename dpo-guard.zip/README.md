# DPO-Guard

**Fine-Tuning a Small LLM for Injection Resistance using Direct Preference Optimization (DPO)**

End-to-end DPO pipeline on Phi-2 / Mistral-7B with cybersecurity preference pairs and Pareto analysis.

- Author: Nehrin Gani
- Context: KAUST VSRP application · CyberSaR Lab
- Timeline: 4–5 weeks
- Compute: Google Colab (free T4) or Colab Pro (~US$10/mo)
- Estimated cost: ~US$10–20 API + optional US$10 Colab Pro

---

## Project goal (English)

Train a small open LLM (Phi-2 2.7B or Mistral-7B-Instruct with 4-bit quantization)
to **resist prompt-injection attacks in cybersecurity contexts**, using **Direct
Preference Optimization (DPO)** over a hand-curated + augmented dataset of
**500+ preference pairs** covering 8 injection classes.

The deliverables are:

1. A fine-tuned LoRA adapter for each of 5 beta values `{0.1, 0.3, 0.5, 0.7, 1.0}`.
2. A cybersecurity preference dataset (`data/construction/preference_pairs_v1.jsonl`).
3. Pre/post evaluation on: (a) 50 held-out injection prompts (resistance rate),
   (b) 50 legitimate security queries (utility retention, LLM-as-judge 0–3).
4. An empirical **utility–resistance Pareto frontier** (`results/pareto_frontier.png`).
5. A research log (`RESEARCH_LOG.md`) documenting every training decision.

---

# COMO EXECUTAR O PROJECTO (passo a passo, para quem nunca fez)

> Esta secção — e **apenas esta** — está em português. Todo o código, comentários
> e restantes ficheiros estão em inglês, conforme pedido.

## 1. O que você precisa instalar no seu computador

| Ferramenta | Para quê | Link (gratuito) |
|---|---|---|
| **Python 3.10+** | Linguagem principal | https://www.python.org/downloads/ |
| **Visual Studio Code** | Editor de código (IDE) | https://code.visualstudio.com/ |
| **Extensão Python (VS Code)** | Autocomplete, debug | Instale dentro do VS Code, aba Extensions → "Python" (Microsoft) |
| **Git** | Controle de versão | https://git-scm.com/downloads |
| **Conta Google** | Para usar Google Colab (T4 grátis) | https://accounts.google.com |
| **Conta Hugging Face** | Baixar modelos (Phi-2 / Mistral) | https://huggingface.co/join |
| **Conta OpenAI (opcional)** | Aumento do dataset com GPT-3.5 (~US$10–20) | https://platform.openai.com |

> **Você NÃO precisa de GPU no seu PC.** O treino roda no Google Colab (GPU T4 gratuita).
> O seu PC serve só para editar código, construir o dataset e visualizar resultados.

## 2. Baixar o projecto e abrir no VS Code

1. Descompacte o ficheiro `dpo-guard.zip` numa pasta, por ex. `C:\Users\voce\dpo-guard` (Windows) ou `~/dpo-guard` (Mac/Linux).
2. Abra o **Visual Studio Code**.
3. Menu → **File → Open Folder…** → escolha a pasta `dpo-guard`.
4. No VS Code, abra o terminal integrado: **Terminal → New Terminal**.

## 3. Criar ambiente virtual Python (isola as bibliotecas)

No terminal do VS Code, dentro da pasta do projecto:

**Windows (PowerShell):**
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

**Mac / Linux:**
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

> Se der erro de "execution policy" no PowerShell, execute uma vez:
> `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`

## 4. Configurar as chaves de API

Copie o ficheiro `.env.example` para `.env` e preencha:

```
HUGGINGFACE_TOKEN=hf_xxx_sua_chave_aqui
OPENAI_API_KEY=sk-xxx_opcional_apenas_se_for_aumentar_dataset
```

- Token Hugging Face: https://huggingface.co/settings/tokens (crie um token **read**).
- Chave OpenAI (opcional): https://platform.openai.com/api-keys

## 5. Construir / verificar o dataset de preferências

Já incluímos exemplos iniciais em `data/construction/preference_pairs_v1.jsonl`
(cobre 8 classes de injeção). Para **aumentar** com paráfrases via GPT-3.5:

```bash
python src/augment_dataset.py --input data/construction/preference_pairs_v1.jsonl \
                              --output data/construction/preference_pairs_augmented.jsonl \
                              --variants 4
```

Isto gera 4 variantes por par, atingindo os 500+ pares alvo.

Depois, divida em treino/teste (80/20, seed=42):

```bash
python src/split_dataset.py --input data/construction/preference_pairs_augmented.jsonl \
                            --train data/train.jsonl --test data/test.jsonl
```

## 6. Treinar no Google Colab (recomendado — GPU gratuita)

1. Acesse https://colab.research.google.com
2. **File → Upload notebook** → escolha `notebooks/DPO_Guard_Training.ipynb`.
3. **Runtime → Change runtime type → GPU (T4)**.
4. Execute as células em ordem. O notebook:
   - Instala dependências
   - Faz upload do seu `data/train.jsonl` e `data/test.jsonl`
   - Treina o modelo para cada `beta ∈ {0.1, 0.3, 0.5, 0.7, 1.0}` (~45–90 min cada)
   - Salva os adapters LoRA em `/content/dpo-guard/adapters/beta_<valor>/`
   - Baixa tudo como zip para o seu PC

## 7. Avaliar e gerar a fronteira de Pareto

Após baixar os adapters do Colab para `models/adapters/`:

```bash
python src/evaluate.py --adapters-dir models/adapters --eval-file data/eval/held_out.jsonl \
                      --output results/metrics.json
python src/plot_pareto.py --metrics results/metrics.json --output results/pareto_frontier.png
```

## 8. Onde está cada coisa

```
dpo-guard/
├── README.md                      ← este ficheiro
├── RESEARCH_LOG.md                ← log de decisões (obrigatório)
├── requirements.txt               ← dependências Python
├── .env.example                   ← modelo do .env
├── configs/
│   └── dpo_config.yaml            ← hiperparâmetros
├── data/
│   ├── construction/
│   │   └── preference_pairs_v1.jsonl   ← pares manuais (sementes)
│   └── eval/
│       ├── held_out_injections.jsonl   ← 50 prompts de injeção
│       └── legitimate_queries.jsonl    ← 50 consultas legítimas
├── notebooks/
│   └── DPO_Guard_Training.ipynb   ← notebook Colab
├── src/
│   ├── augment_dataset.py         ← paráfrases via GPT-3.5
│   ├── split_dataset.py           ← divisão 80/20
│   ├── train_dpo.py               ← treino DPO (executado pelo notebook)
│   ├── evaluate.py                ← resistência + retenção de utilidade
│   ├── plot_pareto.py             ← gráfico da fronteira de Pareto
│   └── utils.py
└── results/                       ← saídas (gráfico, métricas)
```

## 9. Problemas comuns

| Erro | Solução |
|---|---|
| `CUDA out of memory` no Colab | Reduza `per_device_train_batch_size` para 1, aumente `gradient_accumulation_steps` para 16. |
| `401 Unauthorized` ao carregar Mistral | Aceite os termos em https://huggingface.co/mistralai/Mistral-7B-Instruct-v0.1 e faça `huggingface-cli login`. |
| Prefere modelo mais leve | Use `microsoft/phi-2` (default no config). |
| Colab desconecta | Salve adapters no Google Drive a cada beta (o notebook já faz isso). |

---

## English project docs continue in `docs/` and inline in each script.
