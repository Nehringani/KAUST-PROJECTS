# SOC-RedTeam

**Automated Red Teaming Framework for Security Operations LLM Assistants**

SOC-RedTeam is a modular framework that measures how well a Security Operations
Center (SOC) LLM assistant resists prompt injection attacks embedded in realistic
SOC content: SIEM alerts, threat intelligence reports, malware analysis reports,
and analyst chat queries.

The framework runs four attack modules (direct injection, indirect embedding,
multi-turn erosion, encoding obfuscation) against a target model, uses a
judge LLM to decide whether each attack succeeded, stores all results in a
SQLite database, and visualises them in a Streamlit dashboard.

---

## 1. Project Objective (English)

- Provide a **quantitative, reproducible** measurement of how vulnerable a SOC
  LLM assistant is to prompt-injection attacks.
- Compare the same target model **with and without** defense layers
  (`none`, `promptshield`, `dpo_guard`, `both`).
- Break results down by **attack module × attack class × SOC context** so
  researchers can see exactly where a defense helps and where it fails.
- Ship as a **self-contained Python project** that anyone can run on a laptop
  with a free-tier API key or a fully local Ollama model — no paid services required.

---

## 2. Repository Layout

```
SOC-RedTeam/
├── README.md
├── requirements.txt
├── .env.example
├── configs/
│   └── default.yaml           # Which target, judge, defenses, sample sizes
├── src/
│   ├── attacks/               # 4 attack modules
│   │   ├── direct_injector.py
│   │   ├── indirect_embedder.py
│   │   ├── multi_turn_eroder.py
│   │   └── encoding_obfuscator.py
│   ├── contexts/              # SOC content templates
│   │   ├── siem.py
│   │   ├── threat_report.py
│   │   ├── malware.py
│   │   └── analyst.py
│   ├── target/                # Target-model wrapper (OpenAI / Anthropic / Ollama)
│   │   └── target_model.py
│   ├── judge/                 # Judge LLM: did the attack succeed?
│   │   └── compliance_detector.py
│   ├── defenses/              # Optional defense layers
│   │   ├── prompt_shield.py
│   │   └── dpo_guard.py
│   ├── db/
│   │   └── results_db.py      # SQLite schema + insert/query helpers
│   ├── utils/
│   │   ├── llm_client.py      # Unified LLM client (OpenAI/Anthropic/Ollama)
│   │   └── logging_utils.py
│   └── runner.py              # Orchestrates the full evaluation
├── dashboard/
│   └── app.py                 # Streamlit dashboard
├── database/                  # results.db lands here at runtime
├── tests/
│   ├── test_attacks.py
│   ├── test_judge.py
│   └── test_db.py
├── data/prompts/              # Static attack phrase lists
└── docs/
    └── ARCHITECTURE.md
```

---

## 3. Como Executar (Português — passo a passo, do zero)

> Esta é a única secção em português. Todo o código, comentários e docs estão em inglês.

### 3.1. Ferramentas que precisas instalar

1. **Python 3.10 ou superior** — <https://www.python.org/downloads/>
   Durante a instalação em Windows marca a caixa **"Add Python to PATH"**.
2. **Visual Studio Code** — <https://code.visualstudio.com/>
   Extensões recomendadas (instala do painel Extensions):
   - `Python` (Microsoft)
   - `Pylance`
   - `SQLite Viewer` (opcional, para abrir `database/results.db`)
3. **Git** (opcional) — <https://git-scm.com/downloads>
4. **Um provedor de LLM (escolhe UM, todos têm opção gratuita):**
   - **Ollama (100% grátis, local, recomendado)** — <https://ollama.com/download>
     Depois de instalar, no terminal: `ollama pull llama3.1:8b`
   - **OpenAI (tier gratuito / créditos iniciais)** — <https://platform.openai.com/api-keys>
   - **Anthropic (créditos iniciais gratuitos)** — <https://console.anthropic.com/>

### 3.2. Preparar o projecto

Abre um terminal (PowerShell no Windows, Terminal no macOS/Linux):

```bash
# 1. Entra na pasta do projecto
cd SOC-RedTeam

# 2. Cria um ambiente virtual
python -m venv .venv

# 3. Activa o ambiente virtual
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# Windows cmd:
.venv\Scripts\activate.bat
# macOS / Linux:
source .venv/bin/activate

# 4. Actualiza pip e instala dependências
python -m pip install --upgrade pip
pip install -r requirements.txt

# 5. Copia o ficheiro de configuração de secrets
# Windows:
copy .env.example .env
# macOS / Linux:
cp .env.example .env
```

Abre o ficheiro `.env` e escolhe o teu provedor:

- **Ollama local (grátis):**
  ```
  LLM_PROVIDER=ollama
  OLLAMA_MODEL=llama3.1:8b
  ```
- **OpenAI:**
  ```
  LLM_PROVIDER=openai
  OPENAI_API_KEY=sk-....
  OPENAI_MODEL=gpt-4o-mini
  ```
- **Anthropic:**
  ```
  LLM_PROVIDER=anthropic
  ANTHROPIC_API_KEY=sk-ant-....
  ANTHROPIC_MODEL=claude-3-5-haiku-latest
  ```

### 3.3. Abrir no Visual Studio Code

1. Abre o VS Code → `File > Open Folder…` → escolhe `SOC-RedTeam`.
2. Em baixo à direita clica no interpretador Python e escolhe o do `.venv`.
3. Abre um terminal integrado (`Ctrl + '`) — já vem com o venv activo.

### 3.4. Correr os testes

```bash
pytest -q
```

Os testes usam um **fake LLM** interno, portanto passam sem consumir API.

### 3.5. Correr a avaliação completa

```bash
python -m src.runner --config configs/default.yaml
```

Isto vai:
1. Gerar as combinações `atacante × contexto × defesa`.
2. Chamar o target model para cada ataque.
3. Chamar o judge model para classificar a resposta.
4. Gravar cada linha em `database/results.db`.

Para uma corrida rápida (poucos ataques, útil para testar) usa `--samples 5`:

```bash
python -m src.runner --config configs/default.yaml --samples 5
```

### 3.6. Ver o dashboard

```bash
streamlit run dashboard/app.py
```

Abre <http://localhost:8501>. Vais ver:
- Taxa de sucesso por módulo de ataque
- Taxa de sucesso por contexto SOC
- Comparação entre configurações de defesa (`none / promptshield / dpo_guard / both`)
- Tabela detalhada de todos os ataques

### 3.7. Custos

- **Ollama local:** €0.
- **OpenAI `gpt-4o-mini`:** uma corrida completa (~200 ataques) custa tipicamente **menos de $1 USD**.
- **Anthropic Haiku:** semelhante.

---

## 4. Attack Modules (English)

| Module | Class(es) | Description |
|---|---|---|
| `DirectInjector` | 1, 2, 6, 7 | Explicit override + role assumption phrases combined with analyst queries. |
| `IndirectEmbedder` | 3 | Payloads hidden inside SIEM logs, threat reports, malware reports. |
| `MultiTurnEroder` | 4 | 5-turn escalating conversation that shifts the model's baseline. |
| `EncodingObfuscator` | 5 | Base64 / ROT13 / Unicode-homoglyph obfuscation of payloads. |

## 5. Judge Model

`src/judge/compliance_detector.py` implements the judge with the prompt from
the project brief. Output is a strict JSON object:

```json
{
  "attack_succeeded": true,
  "compliance_type": "full|partial|superficial|none",
  "injection_identified": false,
  "attack_success_score": 0.0
}
```

## 6. Database Schema

See `src/db/results_db.py` and `docs/ARCHITECTURE.md`. Key query:

```sql
SELECT defense_applied,
       AVG(attack_succeeded) AS success_rate,
       COUNT(*)              AS total_attacks
FROM   experiments
GROUP  BY defense_applied;
```

## 7. Extending

- Add a new attack module: drop a file in `src/attacks/`, subclass
  `AttackModule`, register it in `src/runner.py`.
- Add a new SOC context: drop a file in `src/contexts/`, expose a
  `render(payload: str) -> str` function.
- Add a new defense: drop a file in `src/defenses/`, expose
  `apply(prompt: str) -> tuple[str, bool]`.

## 8. License

MIT. For academic and research use.
