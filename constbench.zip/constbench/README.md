# ConstitutionBench — Constitutional AI for Cybersecurity SOC Assistants

> Benchmarking Constitutional AI (CAI) principle design for LLM-based SOC
> assistants — evaluating **helpfulness vs. adversarial resistance** on a
> dataset of dual-use cybersecurity queries.
>
> Author: Nehrin Gani · KAUST VSRP Application · CyberSaR Lab
> Status: Research prototype · Runtime: API-only (no GPU) · Est. cost: ~US$15–25

---

## 🇧🇷 GUIA COMPLETO — Como executar o projeto do zero

**Esta seção é a única em português.** Todo o restante (código, comentários,
constituições, dataset, análises) está em inglês, como pedido.

### 1. O que este projeto faz (visão geral em 30 segundos)

Este projeto avalia se **princípios de "Constitutional AI"** (regras escritas
em linguagem natural que guiam um LLM) funcionam bem quando aplicados a um
**assistente de Security Operations Center (SOC)**. Ele:

1. Define **3 constituições** diferentes (genérica, cibersegurança, endurecida
   contra ataques adversariais).
2. Aplica cada uma a **100 consultas de duplo uso** (perguntas que são
   legítimas para um analista de segurança mas perigosas se mal utilizadas).
3. Roda um pipeline **CAI (self-critique + revise)** usando a API de um LLM.
4. Avalia cada resposta em **4 dimensões**: utilidade, resistência,
   consistência, cobertura.
5. Gera **gráficos e um relatório** com os achados (princípios "mortos" e
   princípios "conflitantes").

### 2. Ferramentas que você precisa instalar (tudo gratuito)

| Ferramenta | Para que serve | Link |
|---|---|---|
| **Python 3.10+** | Linguagem do projeto | https://www.python.org/downloads/ |
| **Visual Studio Code** | Editor recomendado | https://code.visualstudio.com/ |
| **Extensão Python (VS Code)** | Suporte a Python no editor | Marketplace do VS Code |
| **Git** (opcional) | Controle de versão | https://git-scm.com/ |
| **Uma chave de API de LLM** | Para chamar Claude ou GPT-4 | Ver passo 4 |

> ⚠️ As únicas coisas pagas são as **chamadas de API** (custo estimado
> US$ 15–25 para rodar o benchmark completo). Você pode reduzir para
> ~US$ 1 rodando apenas em 10 consultas de amostra (`--sample 10`).

### 3. Instalação passo a passo (Windows / Mac / Linux)

**Passo 3.1 — Instalar Python**
1. Baixe Python 3.10 ou superior no link acima.
2. **No Windows**, marque a caixa **"Add Python to PATH"** durante a instalação.
3. Abra um terminal (PowerShell no Windows, Terminal no Mac/Linux) e verifique:
   ```bash
   python --version
   ```
   Deve mostrar algo como `Python 3.10.x` ou superior.

**Passo 3.2 — Instalar o VS Code + extensão Python**
1. Instale o VS Code.
2. Abra o VS Code → aba **Extensions** (Ctrl+Shift+X) → busque **Python** (da
   Microsoft) → clique **Install**.

**Passo 3.3 — Abrir o projeto**
1. Descompacte o arquivo `constbench.zip` numa pasta de sua escolha.
2. No VS Code: **File → Open Folder** → escolha a pasta `constbench`.

**Passo 3.4 — Criar um ambiente virtual (isola as dependências)**

No terminal integrado do VS Code (Ctrl+`):

```bash
# Windows (PowerShell)
python -m venv .venv
.\.venv\Scripts\Activate.ps1

# Mac / Linux
python3 -m venv .venv
source .venv/bin/activate
```

Se aparecer erro de execução de scripts no Windows, rode antes:
```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

**Passo 3.5 — Instalar as dependências**
```bash
pip install -r requirements.txt
```

### 4. Obter uma chave de API (escolha UMA das opções)

**Opção A — Anthropic Claude (recomendada, o projeto usa Claude por padrão):**
1. Crie uma conta em https://console.anthropic.com/
2. Vá em **API Keys** → **Create Key** → copie a chave (começa com `sk-ant-...`).
3. Adicione créditos (mínimo US$ 5).

**Opção B — OpenAI GPT-4:**
1. Crie conta em https://platform.openai.com/
2. **API Keys** → **Create secret key** → copie (começa com `sk-...`).

### 5. Configurar a chave de API

1. Na raiz do projeto, copie o arquivo de exemplo:
   ```bash
   cp .env.example .env      # Mac/Linux
   copy .env.example .env    # Windows
   ```
2. Abra `.env` no VS Code e cole sua chave:
   ```
   ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxx
   # OPENAI_API_KEY=sk-xxxxxxxxxxxxx   # apenas se usar OpenAI
   ```

### 6. Executar o projeto

**Teste rápido (5 consultas, custa alguns centavos):**
```bash
python -m src.run_benchmark --sample 5
```

**Benchmark completo (todas as 100 consultas × 3 constituições):**
```bash
python -m src.run_benchmark
```

**Gerar gráficos e análise:**
```bash
python -m src.analyze
```

Os resultados vão para:
- `results/*.json` — dados brutos das rodadas
- `analysis/plots/*.png` — gráficos (scatter utilidade-vs-resistência, heatmap, etc.)
- `analysis/report.md` — relatório final com achados

### 7. Estrutura do projeto

```
constbench/
├── README.md                        # este arquivo
├── requirements.txt                 # dependências Python
├── .env.example                     # modelo de configuração da API key
├── constitutions/                   # 3 constituições em YAML
│   ├── general_purpose_v1.yaml
│   ├── cybersecurity_v1.yaml
│   └── adversarially_hardened_v1.yaml
├── data/
│   └── dual_use_queries.csv         # 100 consultas de duplo uso
├── src/
│   ├── llm_client.py                # wrapper para Claude/OpenAI
│   ├── constitution.py              # carrega e valida YAML
│   ├── cai_pipeline.py              # gera → critica → revisa
│   ├── evaluator.py                 # avaliação em 4 dimensões
│   ├── run_benchmark.py             # entrypoint principal
│   └── analyze.py                   # gera gráficos e relatório
├── results/                         # JSON de saída (gerado)
└── analysis/                        # gráficos + report (gerado)
```

### 8. Problemas comuns (troubleshooting)

| Erro | Solução |
|---|---|
| `ModuleNotFoundError` | Ative o venv e rode `pip install -r requirements.txt` |
| `authentication_error` | Chave errada no `.env`; verifique se copiou completa |
| `rate_limit_error` | Aguarde 60s ou rode com `--sample 10` |
| `python: command not found` | Use `python3` no Mac/Linux |

---

## English — Project overview (for the record)

See sections above and inline code documentation. Every module, comment,
constitution and dataset entry is written in English.

### Contributions

1. **Three cybersecurity-specific constitutions** (YAML) with full rationale.
2. **A hand-authored dataset** of 100 dual-use SOC queries.
3. **A CAI simulation pipeline** (generate → critique → revise).
4. **A four-dimensional evaluator** (helpfulness / resistance / consistency /
   coverage).
5. **Analysis scripts** that surface *dead principles* and *conflicting
   principles* — the paper-level empirical findings.

### License

MIT — see `LICENSE`.
